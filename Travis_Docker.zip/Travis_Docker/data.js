module.exports = {
  DB: 'mongodb://mongo:27017/mydb'
}